import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { OwncarserviceComponent } from './owncarservice/owncarservice.component';
import { UserloginComponent } from './userlogin/userlogin.component';
import { AppComponent } from './app.component';
import { SplachscreenComponent } from './splachscreen/splachscreen.component';
import { HomeComponent } from './home/home.component';
import { ProfileComponent } from './profile/profile.component';
import { MyappointmentsComponent } from './myappointments/myappointments.component';
import { AuthGuard } from '../app/auth-guard/auth.guard';
import { VendorComponent } from './vendor/vendor.component';
const routes: Routes = [
  {path:'',component:SplachscreenComponent},
  {path:'login',component:UserloginComponent},
  {path:'ocs',component:OwncarserviceComponent,children:[
    {path:'home',component:HomeComponent,canActivate:[AuthGuard]},
    {path:'profile',component:ProfileComponent,canActivate:[AuthGuard]},
    {path:'appointments',component:MyappointmentsComponent,canActivate:[AuthGuard]},
    {path:'appointments/:current',component:MyappointmentsComponent,canActivate:[AuthGuard]},
    {path:'vendor',component:VendorComponent,canActivate:[AuthGuard]}
  ]}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
