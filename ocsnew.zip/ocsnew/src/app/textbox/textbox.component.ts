import { Component, OnInit, Input, Inject, Optional, ViewChild,forwardRef } from '@angular/core';
import { FormControl, FormGroup, FormBuilder, Validators, NgModel, ControlValueAccessor } from '@angular/forms';

@Component({
  selector: 'app-textbox',
  templateUrl: './textbox.component.html',
  styleUrls: ['./textbox.component.css']
})
export class TextboxComponent implements OnInit {




 @Input()
 public Placeholder:String;

 @Input()
 public required:Boolean;
 
 @Input()
 public label:String;
 
 @Input()
 public maxLength:string;
 
 @Input()
 public pattern:string;
 public textvalue:FormGroup;
 
 public errorMsg:String =''
  constructor(private fb:FormBuilder) {
    
   }

  ngOnInit() {
  //  this.textvalue = this.fb.group({
  //    textboxvalue : ['']
  //  })
  // if(this.required === true){
  //   console.log(this.required);
  //  this.textvalue.get('textboxvalue').setValidators([Validators.required]);
  // }
  // if(this.maxLength){
  //   this.textvalue.get('textboxvalue').setValidators([Validators.maxLength(parseInt(this.maxLength))]);
  // }

  // if(this.pattern!= undefined){
  //    if(this.pattern.length>0 ){
  //   this.textvalue.get('textboxvalue').setValidators([Validators.pattern(this.pattern)]);
  //    }
  // }
 // console.log(this.jsonString);
 // console.log(this.textvalue.controls['textboxvalue']);
  }

// get TextBoxValue(){
//   return this.textvalue.get('textboxvalue');
// }

public onBlurMethod(){

  // if(this.required && this.value.length == 0 || this.value == null || this.value == undefined){
  //   this.errorMsg = this.label+" is requried";
  // }else{
  //   this.errorMsg='';
  // }
}



}
