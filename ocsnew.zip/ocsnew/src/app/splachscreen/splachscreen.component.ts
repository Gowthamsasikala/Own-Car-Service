import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-splachscreen',
  templateUrl: './splachscreen.component.html',
  styleUrls: ['./splachscreen.component.css']
})
export class SplachscreenComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit() {
    setTimeout(() => {
      this.route.navigateByUrl("login");
    }, 3000);
  }

}
