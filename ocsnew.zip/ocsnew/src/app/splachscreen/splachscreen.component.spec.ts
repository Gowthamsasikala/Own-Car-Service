import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SplachscreenComponent } from './splachscreen.component';

describe('SplachscreenComponent', () => {
  let component: SplachscreenComponent;
  let fixture: ComponentFixture<SplachscreenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SplachscreenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SplachscreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
