import { Component, OnInit } from '@angular/core';
import { NavigationserviceService } from '../Service/navigationservice.service';


@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css']
})
export class NavigationComponent implements OnInit {

  public toggleHamburger:Boolean = false;
  public navbars:any;
  public a:any;
  constructor(private service :NavigationserviceService) { }

  ngOnInit() {
    const userInfo  = JSON.parse(sessionStorage.getItem('userinfo'));
    console.log(userInfo);
    if(userInfo['typeOfUsers'] === 'Vendor'){
      this.service.getNavbarVendor().subscribe(data=>{
        this.navbars = data;
        console.log(this.navbars);
      });
    }else if(userInfo['typeOfUsers'] === 'User'){
      this.service.getNavbar().subscribe(data=>{
        this.navbars = data;
        console.log(this.navbars);
      });
    }else if(userInfo['typeOfUsers'] === 'Delivery Partner'){
      this.service.getNavbarDP().subscribe(data=>{
        this.navbars = data;
        console.log(this.navbars);
      });
    }
  

  }

  hamburger(){
    this.toggleHamburger = !this.toggleHamburger;
  }
 
  close(data:any){
    this.toggleHamburger = false;
    if(data['nav_name'] === 'Logout'){
      sessionStorage.clear();

    }
  }

}
