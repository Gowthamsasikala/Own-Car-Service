import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { FormBuilder, FormGroup } from '@angular/forms';
import { UserregistrationService } from '../Service/userregistration.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
public userInfo:any;
public image:any;
public editProfile:FormGroup;
public userName:string;
public getUser:any;
public successmsg:string;'';

  constructor(private sanitization:DomSanitizer,private fb:FormBuilder,private profileService:UserregistrationService) { }

  ngOnInit() {
    this.userInfo = JSON.parse(sessionStorage.getItem('userinfo'));
    console.log(this.userInfo);
    this.editProfile = this.fb.group({
      userName:[''],
      emailId:[''],
      phoneNumber:[''],
      address:[''],
      userId : [''],
      password : [''],
      confirmPassword : [''],
      dateOfRegistration : [''],
      imgUrl : [''],
      typeOfUsers : ['']
    
    
    }) 
    this.profileService.getUserById(this.userInfo['userId']).subscribe(data=>{
this.getUser = data;
console.log(this.getUser);
this.userName = this.getUser['userName'];
this.image = this.sanitization.bypassSecurityTrustUrl(this.getUser['imgUrl']);
this.valueMapper(this.getUser);

 
    });
   
   
  }


  update(){
    this.editProfile.patchValue({
      userName : this.editProfile.get('userName').value,
      emailId : this.editProfile.get('emailId').value,
      phoneNumber : this.editProfile.get('phoneNumber').value,
      address : this.editProfile.get('address').value
    })
this.profileService.updateProfile(this.editProfile.value).subscribe(data=>{
  console.log(data);
  this.userName = data['userName'];
  this.valueMapper(data);
  this.successmsg ='Profile successfully Updated..';
  
})
    console.log(this.editProfile.value);
  }


valueMapper(mapper:any){
  console.log("mapper",mapper);
  this.editProfile.patchValue({
    userName:mapper['userName'],
    emailId:mapper['emailId'],
    phoneNumber:mapper['phoneNumber'],
    address:mapper['address'],
    userId : mapper['userId'],
    password : mapper['password'],
    confirmPassword : mapper['confirmPassword'],
    dateOfRegistration : mapper['dateOfRegistration'],
    imgUrl : mapper['imgUrl'],
    typeOfUsers : mapper['typeOfUsers']


  })  
  console.log(this.editProfile.value);  
}


}
