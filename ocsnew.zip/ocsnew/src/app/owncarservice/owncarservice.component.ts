import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-owncarservice',
  templateUrl: './owncarservice.component.html',
  styleUrls: ['./owncarservice.component.css']
})
export class OwncarserviceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
