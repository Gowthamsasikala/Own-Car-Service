import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { UserregistrationService } from '../Service/userregistration.service';
import { AuthService } from '../auth.service';
@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {

  public firstpage:Boolean = true;
  public signup:Boolean=false;
  public signin:Boolean = false;
  public formImgData:FormData;
  public displayText:String = 'OCS';
  public signinform:FormGroup;
  public signUpform:FormGroup;
  public uploadImgboolean:Boolean = false;
  public errorMsg:string='';
  public isLoginMsg:string='';
  public typeOfUser:any;
  constructor(private route:Router,private fb:FormBuilder,private userService:UserregistrationService,private service:AuthService) { }

  ngOnInit() {
this.signinform = this.fb.group({
  EmailId:['',[Validators.required,Validators.email]],
  password:['',[Validators.required]]
})

this.signUpform = this.fb.group({
  userName:['',[Validators.required,Validators.pattern("[a-zA-Z]*")]],
  emailId :['',[Validators.required,Validators.email]],
  phoneNumber :['',[Validators.required,Validators.pattern("^[0-9]{10}$")]],
  address :['',[Validators.required]],
  password :['',[Validators.required]],
  confirmPassword :['',[Validators.required]],
  userId:[''],
  dateOfRegistration:[''],
  typeOfUsers:['',[Validators.required]],
  imgUrl:['']

},{
  validator : [this.checktwopasswords('password','confirmPassword')]
})

this.userService.getTypeOfUser().subscribe(data=>{
  this.typeOfUser = data;
})

this.service.logout();

  }

public changeContainer(page:String){
this.firstpage = false;
if(page === 'signup'){
this.signup = true;
this.displayText = 'Sign Up';
}else{
this.signin = true;
this.displayText = 'Sign In';
}
}

myFile(img:any){

  let file = img.target.files[0];  
  console.log(file.name);
  const keynames = file.name+"-"+this.signUpform.get('userName').value;
  const formData = new FormData();
  formData.append('uploadfile',file);
  formData.append('keyname',keynames);
  this.formImgData = formData;

  }

  signIn(){
    this.signin = true;
    this.signup = false;
    this.displayText = 'Sign In';
    
  }

  changeTypeofUser(event) {
    this.signUpform.patchValue({
      typeOfUsers: event.target.value
    });
    
  }

  signUp(){
    this.signin = false;
    this.signup = true;
    this.displayText = 'Sign Up';
  }

  login(){
    if(this.signinform.valid){
      console.log(this.signinform.value);
      this.userService.Authentication(this.signinform.value).subscribe(data=>{
        console.log(data);
        if(data['status'] === 'Succeed'){
         this.isLoginMsg = '';
         sessionStorage.setItem('userinfo',JSON.stringify(data['users']));
         sessionStorage.setItem('isLoggedIn', "true");
         if(data['users']['typeOfUsers']==='User'){
          this.route.navigateByUrl("ocs/home");
         }else if(data['users']['typeOfUsers']==='Vendor'){
          this.route.navigateByUrl("ocs/vendor");            
         }else if(data['users']['typeOfUsers']==='Delivery Partner'){
          
         }
        }else if(data['status'] === 'Failure'){
         this.isLoginMsg = 'Email Id / Password is incorrect';
        }
      })
    }
   
  }

public checktwopasswords(password,confirmpassword){
return (form:FormGroup)=>{
  const password1 = form.controls[password];
  const confirmpassword1 = form.controls[confirmpassword];
 
  if(confirmpassword1.errors && !confirmpassword1.errors.misMatch){
    return;
  }

  if(password1.value != confirmpassword1.value){
    confirmpassword1.setErrors({misMatch:true});
  }else{
    confirmpassword1.setErrors(null);
  }

}
}

createAccount(){
   console.log(this.signUpform);
  if(this.signUpform.valid){
    console.log(this.formImgData);
    if(this.formImgData == undefined){
 this.uploadImgboolean = true;
 this.errorMsg = 'Please fill all the required fields';
    }else{
      this.uploadImgboolean = false;
      this.errorMsg ='';
      this.userService.uploadUserprofile(this.formImgData).subscribe(data=>{
        console.log(data);
        var cdate = new Date();
        var dateOfReg = cdate.getDate()+"/"+(cdate.getMonth()+1)+"/"+cdate.getFullYear();
        if(data['status']==='Success'){
          this.signUpform.patchValue({
            imgUrl:data['responseMsg'],
            dateOfRegistration : dateOfReg
          })
          console.log(this.signUpform.value);
          this.userService.createnewAccount(this.signUpform.value).subscribe(data=>{
            console.log(data);
            if(data['status']==='Succeed'){
              this.route.navigateByUrl("login");
              this.signin = true;
              this.signup = false;
              this.displayText = 'Sign In';

            }
          })
        }
      })
    }
  }else{
     this.errorMsg = 'Please fill all the required fields';
  }
}

get signinPassword(){ return this.signinform.get('password')}
get signinEmailId(){ return this.signinform.get('EmailId')}
get signUpUsername(){ return this.signUpform.get('userName')}
get signUpEmailId(){ return this.signUpform.get('emailId')}
get signUpPhonenumber(){ return this.signUpform.get('phoneNumber')}
get signUpAddress(){ return this.signUpform.get('address')}
get signUpPassword(){ return this.signUpform.get('password')}
get signUpConformPassword(){ return this.signUpform.get('confirmPassword')}
get signUpGetAllTypeOfUser(){return this.signUpform.get('typeOfUsers')}







}
