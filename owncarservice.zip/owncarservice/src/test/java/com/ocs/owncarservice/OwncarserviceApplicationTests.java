package com.ocs.owncarservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OwncarserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
