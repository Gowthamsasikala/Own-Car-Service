package com.ocs.owncarservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OwncarserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OwncarserviceApplication.class, args);
	}

}
