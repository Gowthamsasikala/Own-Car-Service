package com.ocs.owncarservice.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.ocs.owncarservice.Entity.Vendor;
import com.ocs.owncarservice.ResponseMessage.ResponseMessage;
import com.ocs.owncarservice.Service.VendorImpl;

@RestController
@RequestMapping(value="/Vendor")
@CrossOrigin("*")
public class VendorController {

	@Autowired
	VendorImpl vService;

	
	@PostMapping(value="/CreateVendor")
	public ResponseEntity<?> CreateAppointment(@RequestBody Vendor appoint){
		try {
			Vendor vendor = vService.createNewVendor(appoint);
			return new ResponseEntity<Vendor>(vendor,HttpStatus.OK);
		}catch(Exception e) {
			ResponseMessage exceptions = new ResponseMessage();
			exceptions.setStatus("Failed");
			exceptions.setResponseMsg(e.getMessage());
			return new ResponseEntity<ResponseMessage>(exceptions,HttpStatus.BAD_GATEWAY);
		}
	}
	
	@GetMapping(value="/GetAllPackages")
	public ResponseEntity<?> getAllPackage(){
		ResponseMessage response = new ResponseMessage();
		try {
				return new ResponseEntity<List<com.ocs.owncarservice.Entity.Package>>(vService.getAllPackages(),HttpStatus.OK);
			}
		catch(Exception e) {
		response.setStatus("Error");
		response.setResponseMsg(e.getMessage());
		}
		return new ResponseEntity<ResponseMessage>(response,HttpStatus.BAD_REQUEST);
		
	}
	
//	 @PostMapping("/api/file/vendor/upload")
//	    public ResponseEntity<ResponseMessage> uploadVendorPhotoMultipartFile(@RequestParam("keynames") String keyNames, @RequestParam("uploadfiles") MultipartFile files) {
//	    	try {
//	    		System.out.println("hi");
//	    	s3service.uploadFile(keyNames, files);
//	    	ResponseMessage r = new ResponseMessage();
//	    	r.setStatus("Success");
//	    	r.setResponseMsg("https://owncarservicw.s3.ap-south-1.amazonaws.com/"+keyNames);
//	        return new ResponseEntity<ResponseMessage>(r,HttpStatus.OK);
//	    }catch(Exception e) {
//	    	ResponseMessage re =new ResponseMessage();
//			re.setStatus("Failed");
//			re.setResponseMsg(e.getMessage());
//			return new ResponseEntity<ResponseMessage>(re,HttpStatus.OK);
//	    }
//	    } 
	
	@GetMapping(value="/GetAllVendor")
	public ResponseEntity<?> getAllVendor(){
		ResponseMessage response = new ResponseMessage();
		try {
				return new ResponseEntity<List<Vendor>>(vService.getAllVendors(),HttpStatus.OK);
			}
		catch(Exception e) {
		response.setStatus("Error");
		response.setResponseMsg(e.getMessage());
		}
		return new ResponseEntity<ResponseMessage>(response,HttpStatus.BAD_REQUEST);
		
	}
	
	
	
}
