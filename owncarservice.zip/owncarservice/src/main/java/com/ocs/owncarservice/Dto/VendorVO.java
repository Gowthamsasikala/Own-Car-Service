package com.ocs.owncarservice.Dto;

public class VendorVO {

private String vendorId;
	
	private String vendorName;
	
	private String vendorAddress;
	
	private String vendorPhonenumber;
	
	private String vendorPincode;
	
	private String packages;
	
	private String price;

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVendorAddress() {
		return vendorAddress;
	}

	public void setVendorAddress(String vendorAddress) {
		this.vendorAddress = vendorAddress;
	}

	public String getVendorPhonenumber() {
		return vendorPhonenumber;
	}

	public void setVendorPhonenumber(String vendorPhonenumber) {
		this.vendorPhonenumber = vendorPhonenumber;
	}

	public String getVendorPincode() {
		return vendorPincode;
	}

	public void setVendorPincode(String vendorPincode) {
		this.vendorPincode = vendorPincode;
	}

	public String getPackages() {
		return packages;
	}

	public void setPackages(String packages) {
		this.packages = packages;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
	
	
	
	
}
