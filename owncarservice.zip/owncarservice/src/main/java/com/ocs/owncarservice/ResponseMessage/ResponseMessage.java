package com.ocs.owncarservice.ResponseMessage;

public class ResponseMessage {

	
	private String status;
	private String responseMsg;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getResponseMsg() {
		return responseMsg;
	}
	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}
	
}
