import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-textbox',
  templateUrl: './textbox.component.html',
  styleUrls: ['./textbox.component.css']
})
export class TextboxComponent implements OnInit {

 @Input()
 public Placeholder:String;

 @Input()
 public required:Boolean;
 
 @Input()
 public label:String;
 
 @Input()
 public maxLength:String;
 
 @Input()
 public pattern:String;

 public value:String='';

 public errorMsg:String =''
  constructor() { }
  




  ngOnInit() {
  }

public onBlurMethod(){
  if(this.required && this.value.length == 0 || this.value == null || this.value == undefined){
    this.errorMsg = this.label+" is requried";
  }else{
    this.errorMsg='';
  }
}

}
