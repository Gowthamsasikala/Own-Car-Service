import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserregistrationService {

  constructor(private http:HttpClient) { }

  Authentication(signinObj){
   return this.http.post("http://localhost:9090/UserRegistration/Authentication",signinObj);
  }

  uploadUserprofile(form:FormData){
    return this.http.post("http://localhost:9090/UserRegistration/api/file/upload",form);
  }

  createnewAccount(signupobj){
    return this.http.post("http://localhost:9090/UserRegistration/CreateAccount",signupobj);
  }

  updateProfile(updateuser){
    return this.http.put("http://localhost:9090/UserRegistration/updateAccount",updateuser);
  }

  getUserById(userid:string){
    
    return this.http.get("http://localhost:9090/UserRegistration/GetByUserId/"+userid);
  }

}
