import { Injectable } from '@angular/core';
import {HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class NavigationserviceService {

  constructor(private http:HttpClient) { }

getNavbar(){
  return  this.http.get('../assets/metadata/navigation.json');
}

}
