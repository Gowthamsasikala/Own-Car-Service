import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HomeService {

  constructor(private http:HttpClient) { }

  getAllVendors(){
    return this.http.get("http://localhost:9090/Vendor/GetAllVendor");
  }

  getVehicleType(){
    return this.http.get("../assets/metadata/vehicleType.json");
  }

  getVehicleBrand(){
    return this.http.get("../assets/metadata/VehicleBrand.json");
  }

  getVehiclepackage(){
    return this.http.get("../assets/metadata/Vehiclepackage.json");
  }

}
