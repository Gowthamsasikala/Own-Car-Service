import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-splachscreen',
  templateUrl: './splachscreen.component.html',
  styleUrls: ['./splachscreen.component.css']
})
export class SplachscreenComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
