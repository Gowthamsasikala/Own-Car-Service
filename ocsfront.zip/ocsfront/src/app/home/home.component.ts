import { Component, OnInit } from '@angular/core';
import { HomeService } from '../Service/home.service';
import {CalendarModule} from 'primeng/calendar';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
   
  public getvendors:any;
  public vehicleType:any;
  public vehicleBrand:any;
  public vehiclePackage:any;
  value: Date;
  public appointmentForm:FormGroup;
  constructor(private vendorHomeService:HomeService,private fb:FormBuilder) { }

  ngOnInit() {
    this.vendorHomeService.getAllVendors().subscribe(data=>{
      console.log(data);
      this.getvendors = data;
    });
    this.vendorHomeService.getVehicleType().subscribe(data=>{
      this.vehicleType = data;
    });
    this.vendorHomeService.getVehicleBrand().subscribe(data=>{
      this.vehicleBrand = data;
    });
    this.vendorHomeService.getVehiclepackage().subscribe(data=>{
      this.vehiclePackage = data;
    });
  
    this.appointmentForm = this.fb.group({
      appointmentId:[''],
      pincode:['',Validators.compose([Validators.required])],
      vehicle:['',Validators.compose([Validators.required])],
      vehicleType:['',Validators.compose([Validators.required])],
      vehicleBrand:['',Validators.compose([Validators.required])],
      vehicleModel:['',Validators.compose([Validators.required])],
      packages:['',Validators.compose([Validators.required])],
      address:['',Validators.compose([Validators.required])],
      landmark:['',Validators.compose([Validators.required])],
      pickUpTime:['',Validators.compose([Validators.required])],
      appointmentDateTime:['',Validators.compose([Validators.required])],
      carBikeNumberPlate:['',Validators.compose([Validators.required])],
      status:['In Progress',Validators.compose([Validators.required])]
      
    })


  }

  vehicle(type){
    console.log(type);
    this.appointmentForm.patchValue({
      vehicle:type
    })
  }

  changeType(event){
this.appointmentForm.patchValue({
  vehicleType:event.target.value
})
console.log(this.appointmentForm.get('vehicleType'));
  }

  changeBrand(event){
    this.appointmentForm.patchValue({
      vehicleBrand:event.target.value
    })
console.log(this.appointmentForm.value);
    
  }

  changePackage(event){
    this.appointmentForm.setValue({
      packages:event.target.value
    })
console.log(this.appointmentForm.value);
    
  }

}
