import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {

  public firstpage:Boolean = true;
  public signup:Boolean=false;
  public signin:Boolean = false;
  public formImgData:FormData;
  public displayText:String = 'OCS';
  constructor() { }

  ngOnInit() {
  }

public changeContainer(page:String){
this.firstpage = false;
if(page === 'signup'){
this.signup = true;
this.displayText = 'Sign Up';
}else{
this.signin = true;
this.displayText = 'Sign In';
}
}

myFile(img:any){

  let file = img.target.files[0];  
  console.log(file.name);
  const formData = new FormData();
  formData.append('uploadfile',file);
  formData.append('keyname',file.name);
  this.formImgData = formData;
  }

  signIn(){
    this.signin = true;
    this.signup = false;
    this.displayText = 'Sign In';
  }


  signUp(){
    this.signin = false;
    this.signup = true;
    this.displayText = 'Sign Up';
  }
}
