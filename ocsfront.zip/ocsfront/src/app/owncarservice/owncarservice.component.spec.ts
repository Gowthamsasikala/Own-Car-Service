import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OwncarserviceComponent } from './owncarservice.component';

describe('OwncarserviceComponent', () => {
  let component: OwncarserviceComponent;
  let fixture: ComponentFixture<OwncarserviceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OwncarserviceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OwncarserviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
